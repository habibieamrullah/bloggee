<?php
session_start();
$username = "habibie";
$password = "habibie123";
$filedb = "data.txt";
?>