<?php
//English

switch($text){
	case "Daftar Tulisan" : $tt =  "All Posts"; break;
	case "Galeri Gambar" : $tt =  "Image Gallery"; break;
	case "Judul Website" : $tt =  "Site Title"; break;
	case "Keluar" : $tt =  "Logout"; break;
	case "Judul" : $tt =  "Title"; break;
	case "Lihat" : $tt =  "View"; break;
	case "Silahkan coba lagi." : $tt =  "Please try again"; break;
	case "Kamu berhasil keluar" : $tt =  "You are logged out"; break;
	case "Tanggal" : $tt =  "Date"; break;
	case "Ubah" : $tt =  "Edit"; break;
	case "Pengaturan" : $tt =  "Settings"; break;
	case "Tambah Tulisan" : $tt =  "New Post"; break;
	case "Tampilan" : $tt =  "Themes"; break;
	case "Login sukses!" : $tt =  "Login success!"; break;
	case "Bahasa" : $tt =  "Language"; break;
	case "Login gagal!" : $tt =  "Login failed!"; break;
	case "Tunggu sejenak, Anda akan diarahkan ke halaman Admin Panel." : $tt =  "Please wait, you will be redirected to Admin Panel page."; break;
	case "Ya" : $tt =  "Yes"; break;
	case "Tunggu sejenak, kamu akan diarahkan ke halaman Login." : $tt =  "Please wait, you will be redirected to login page."; break;
	case "Tidak" : $tt =  "No"; break;
	case "Gambar Andalan" : $tt =  "Featured Image"; break;
	case "Sekilas" : $tt =  "Excerpt"; break;
	case "Simpan" : $tt =  "Save"; break;
	case "Unggah" : $tt =  "Upload"; break;
	case "Hapus" : $tt =  "Delete"; break;
	case "Konten" : $tt =  "Content"; break;
	case "Tema Situs" : $tt =  "Site Theme"; break;
	case "Tema Admin" : $tt =  "Admin Theme"; break;
	case "Link Dinamis (link tulisan berubah saat judul berubah)" : $tt =  "Dynamic Links (change post link whenever post title is updated)"; break;
	case "Teks Footer" : $tt =  "Footer Text"; break;
	case "URL Situs" : $tt =  "Site URL"; break;
	default : $tt =  "UNTRANSLATED (" . $text . ")";
}
