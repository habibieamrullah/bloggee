<?php
//French

switch($text){
	case "Daftar Tulisan" : $tt =  "Tous les messages"; break;
	case "Galeri Gambar" : $tt =  "Galerie d'images"; break;
	case "Judul Website" : $tt =  "Titre du site"; break;
	case "Keluar" : $tt =  "Se déconnecter"; break;
	case "Judul" : $tt =  "Titre"; break;
	case "Lihat" : $tt =  "Vue"; break;
	case "Silahkan coba lagi." : $tt =  "Veuillez réessayer"; break;
	case "Kamu berhasil keluar" : $tt =  "Vous êtes déconnecté"; break;
	case "Tanggal" : $tt =  "Date"; break;
	case "Ubah" : $tt =  "Éditer"; break;
	case "Pengaturan" : $tt =  "Paramètres"; break;
	case "Tambah Tulisan" : $tt =  "Nouveau poste"; break;
	case "Tampilan" : $tt =  "Thèmes"; break;
	case "Login sukses!" : $tt =  "Connexion réussie !"; break;
	case "Bahasa" : $tt =  "Langue"; break;
	case "Login gagal!" : $tt =  "Échec de la connexion!"; break;
	case "Tunggu sejenak, Anda akan diarahkan ke halaman Admin Panel." : $tt =  "Veuillez patienter, vous serez redirigé vers la page du panneau d'administration."; break;
	case "Ya" : $tt =  "Yes"; break;
	case "Tunggu sejenak, kamu akan diarahkan ke halaman Login." : $tt =  "Veuillez patienter, vous serez redirigé vers la page de connexion."; break;
	case "Tidak" : $tt =  "Non"; break;
	case "Gambar Andalan" : $tt =  "L'image sélectionnée"; break;
	case "Sekilas" : $tt =  "Extrait"; break;
	case "Simpan" : $tt =  "mettre à jour"; break;
	case "Unggah" : $tt =  "Télécharger"; break;
	case "Hapus" : $tt =  "Effacer"; break;
	case "Konten" : $tt =  "Teneur"; break;
	case "Tema Situs" : $tt =  "Thème du site Web"; break;
	case "Tema Admin" : $tt =  "Thème d'administration"; break;
	case "Link Dinamis (link tulisan berubah saat judul berubah)" : $tt =  "Liens dynamiques (modifier le lien de publication chaque fois que le titre de la publication est mis à jour)"; break;
	case "Teks Footer" : $tt =  "Texte de pied de page"; break;
	case "URL Situs" : $tt =  "URL du site"; break;
	default : $tt =  "UNTRANSLATED (" . $text . ")";
}
