<?php
$result = "Hello!";

